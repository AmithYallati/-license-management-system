import requests
import json

class LicenseValidator:
    def __init__(self, license_key, server_url):
        self.license_key = license_key
        self.server_url = server_url
        self.offline_mode = False

    def validate_license(self):
        if self.offline_mode:
            print("Running in offline mode, limited functionality.")
            return True  # Allow limited functionality in offline mode

        try:
            response = requests.post(f'{self.server_url}/validate_license', json={'license_key': self.license_key})
            if response.status_code == 200:
                data = response.json()
                if data['valid']:
                    print("License is valid.")
                    return True
                else:
                    print("License is invalid or expired.")
                    return False
            else:
                print("Error communicating with the server.")
                return False
        except Exception as e:
            print(f"Error: {e}")
            self.offline_mode = True
            return self.validate_license()

# Example usage
validator = LicenseValidator('your-license-key', 'http://localhost:5000')
validator.validate_license()
