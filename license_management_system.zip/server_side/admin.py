from flask import Flask, render_template, request, redirect, url_for
from datetime import datetime, timedelta

app = Flask(__name__)

licenses = {
    "your-license-key": {
        "valid_until": datetime.now() + timedelta(days=30),
        "active": True
    }
}

@app.route('/')
def dashboard():
    return render_template('dashboard.html', licenses=licenses)

@app.route('/revoke/<license_key>')
def revoke_license(license_key):
    if license_key in licenses:
        licenses[license_key]['active'] = False
    return redirect(url_for('dashboard'))

@app.route('/add_license', methods=['POST'])
def add_license():
    license_key = request.form.get('license_key')
    valid_days = int(request.form.get('valid_days'))
    licenses[license_key] = {
        "valid_until": datetime.now() + timedelta(days=valid_days),
        "active": True
    }
    return redirect(url_for('dashboard'))

if __name__ == '__main__':
    app.run(debug=True)
