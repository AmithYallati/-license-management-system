from flask import Flask, request, jsonify
from datetime import datetime, timedelta

app = Flask(__name__)

# Dummy license data (in a real scenario, this would be stored in a database)
licenses = {
    "your-license-key": {
        "valid_until": datetime.now() + timedelta(days=30),  # License valid for 30 days
        "active": True
    }
}

@app.route('/validate_license', methods=['POST'])
def validate_license():
    data = request.get_json()
    license_key = data.get('license_key')
    license_info = licenses.get(license_key)

    if license_info:
        if license_info['active'] and license_info['valid_until'] > datetime.now():
            return jsonify({"valid": True})
        else:
            return jsonify({"valid": False}), 400
    return jsonify({"valid": False}), 404

@app.route('/revoke_license', methods=['POST'])
def revoke_license():
    data = request.get_json()
    license_key = data.get('license_key')
    
    if license_key in licenses:
        licenses[license_key]['active'] = False
        return jsonify({"status": "License revoked"})
    
    return jsonify({"error": "License not found"}), 404

if __name__ == '__main__':
    app.run(debug=True)
